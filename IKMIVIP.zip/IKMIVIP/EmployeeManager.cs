﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace IKMIVIP
{
    public class EmployeeManager
    {
        static string stringdatasource = "Data Source=DESKTOP-016Q9O4;Initial Catalog=IKMIVIP;Integrated Security=True";

        public static void EmployeeReader(int number)
        {
            
            SqlConnection connection = new SqlConnection(stringdatasource);
            connection.Open();
            string selectQuery = $"SELECT [EmployeeNO], [Name], [SurName], [EntryTime], [Adress], [WagePer], [TotalMinPerMonth] FROM [dbo].[Employee] where EmployeeNO ={number}";
            SqlCommand sqlCommand = new SqlCommand(selectQuery, connection);
            SqlDataReader sqlDataReader;
            sqlDataReader = sqlCommand.ExecuteReader();

            while (sqlDataReader.Read())
            {
                Console.WriteLine($"Istifadeci nomresi {(int)sqlDataReader.GetValue(0)}");
                Console.WriteLine($"Istifadeci adi {(string)sqlDataReader.GetValue(1)}");
                Console.WriteLine($"Istifadeci soyadi {(string)sqlDataReader.GetValue(2)}");
                Console.WriteLine($"Istifadeci giriw vaxti {(DateTime)sqlDataReader.GetValue(3)}");
                Console.WriteLine($"Istifadeci adresi {(string)sqlDataReader.GetValue(4)}");
                Console.WriteLine($"Istifadeci iw emsai {(int)sqlDataReader.GetValue(5)}");
                Console.WriteLine($"Istifadeci 1 ay erzinden iwlediyi deqiqe {(int)sqlDataReader.GetValue(6)}");
            }
        }

        public static void EmployeeGetInfoPerMonth()
        {
            double currentPermonth = 0;
            int month = DateTime.Now.Month;
            Console.WriteLine("Isdifadecinin nomresini daxil edin");
            int number=Convert.ToInt32(Console.ReadLine());
            SqlConnection connection = new SqlConnection(stringdatasource);
            connection.Open();
            string selectQuery = $"SELECT [EmpolyeeNo], Employee.Name, Employee.SurName, [Day], [EntryHour], [EntryMinute], [ExitHour], [ExitMinute], [CurrentMonth] FROM [dbo].[WorkTime] inner join Employee on EmployeeNO = Employee.EmployeeNO where Employee.EmployeeNO = {number} and CurrentMonth = {month}";
            SqlCommand sqlCommand = new SqlCommand(selectQuery, connection);
            SqlDataReader sqlDataReader;
            sqlDataReader = sqlCommand.ExecuteReader();

            while (sqlDataReader.Read())
            {
                Console.Clear();
                Console.WriteLine($"Istifadeci nomresi {(int)sqlDataReader.GetValue(0)}");
                Console.WriteLine($"Istifadeci adi {(string)sqlDataReader.GetValue(1)}");
                Console.WriteLine($"Istifadeci soyadi {(string)sqlDataReader.GetValue(2)}");
                Console.WriteLine($"Istifadeci iwe giriw gunu {(int)sqlDataReader.GetValue(3)}");
                Console.WriteLine($"Istifadeci giriw saati {(int)sqlDataReader.GetValue(4)}");
                Console.WriteLine($"Istifadeci giriw deqiqesi {(int)sqlDataReader.GetValue(5)}");
                Console.WriteLine($"Istifadeci cixiw vaxti {(int)sqlDataReader.GetValue(6)}");
                Console.WriteLine($"Istifadeci cixiw deqiqesi {(int)sqlDataReader.GetValue(7)}");

                currentPermonth = currentPermonth + Math.Floor(Convert.ToDouble((((((int)sqlDataReader.GetValue(6) * 60) - ((int)sqlDataReader.GetValue(4) * 60)) + ((int)sqlDataReader.GetValue(7) - (int)sqlDataReader.GetValue(5))) / 60)));
            }

            Console.WriteLine($"iwcini iwe geldiyi toplam Ayliq vaxt {currentPermonth}");
        }
        public static void EmployeeGetAdress()
        {
            Console.Write("Iscinin adresin daxil edin: ");
            string Adress=Console.ReadLine();
            SqlConnection connection = new SqlConnection(stringdatasource);
            connection.Open();
            string selectQuery = $"SELECT [Adress],[EmployeeNO],[Name],[SurName],[WagePer] FROM [dbo].[Employee] where Adress ='{Adress}'";
            SqlCommand sqlCommand = new SqlCommand(selectQuery, connection);
            SqlDataReader sqlDataReader;
            sqlDataReader = sqlCommand.ExecuteReader();

            while (sqlDataReader.Read())
            {
                Console.WriteLine($"Istifadeci adresi {(string)sqlDataReader.GetValue(0)}");
                Console.WriteLine($"Istifadeci nomresi {(int)sqlDataReader.GetValue(1)}");
                Console.WriteLine($"Istifadeci adi {(string)sqlDataReader.GetValue(2)}");
                Console.WriteLine($"Istifadeci soyadi {(string)sqlDataReader.GetValue(3)}");
                Console.WriteLine($"Istifadeci iw emsai {(int)sqlDataReader.GetValue(4)}");

            }
        }

        public static void EmployyeCountPerYear()
        {
            Console.WriteLine("Ili daxil edin");
            int year=Convert.ToInt32(Console.ReadLine());
            SqlConnection connection = new SqlConnection(stringdatasource);
            connection.Open();
            string selectQuery = $"select [EntryTime],[Name],[SurName]from Employee where EntryTime ={year}";
            SqlCommand sqlCommand = new SqlCommand(selectQuery, connection);
            SqlDataReader sqlDataReader;
            sqlDataReader = sqlCommand.ExecuteReader();
            while (sqlDataReader.Read())
            {
                Console.WriteLine($"Isdifadecinin daxil oldugu il{(int)sqlDataReader.GetValue(0)}");
                Console.WriteLine($"isdifadecinin adi {(string)sqlDataReader.GetValue(1)}");
                Console.WriteLine($"Isdifadecinin soyadi{(string)sqlDataReader.GetValue(2)}");

            }

        }

        public static void EmployeeGotLater()
        {
            int currentGotLater = 0;
            Console.WriteLine("Isdifadecinin Nomresini daxil edin");
            int number = Convert.ToInt32(Console.ReadLine());
            SqlConnection connection = new SqlConnection(stringdatasource);
            connection.Open();
            string selectQuery = $"select EmpolyeeNo from[dbo].[WorkTime]  EntryHour > 10 order by EntryHour where EmployeeNo={number}";
            SqlCommand sqlCommand = new SqlCommand(selectQuery, connection);
            SqlDataReader sqlDataReader;
            sqlDataReader = sqlCommand.ExecuteReader();

            while (sqlDataReader.Read())
            {
                Console.Clear();
                Console.WriteLine($"Isdifadeci nomresi{(int)sqlDataReader.GetValue(0)}");
                Console.WriteLine($"Isdifadecinin nece defe gecik{(int)sqlDataReader.GetValue(1)}");
                currentGotLater = currentGotLater + (int)sqlDataReader.GetValue(1);
            }
            Console.WriteLine($"iscinin Ay uzre Toplam gecikdiyi say {currentGotLater}");
        }

        public static void EmployeeUpdate()
        {
          
            Console.WriteLine("Isdifadecinin Nomresini daxil edin");
            int number = Convert.ToInt32(Console.ReadLine());
            EmployeeManager.EmployeeReader(number);
            Console.WriteLine("<========================================>");
            SqlConnection connection = new SqlConnection(stringdatasource);
            connection.Open();
            Console.WriteLine("Yeni adi daxil edin");
            string name = Console.ReadLine();
            Console.WriteLine("Yeni soyadi daxil edin");
            string surname = Console.ReadLine();

            Console.WriteLine("Yeni iw vaxtini daxil edin (gun.ay.il)");
            DateTime entryTime = Convert.ToDateTime(Convert.ToDateTime(Console.ReadLine()).ToString("dd/MM/yyyy"));


            Console.WriteLine("Yeni adresi daxil edin");
            string adress = Console.ReadLine();

            Console.WriteLine("Yeni iw emsalini daxil edin");
            int wagePer = Convert.ToInt32(Console.ReadLine());

            string selectQuery = $"UPDATE [dbo].[Employee] SET [Name] = '{name}', [SurName] = '{surname}', [EntryTime] = '{entryTime}', [Adress] = '{adress}', [WagePer] = {wagePer} where EmployeeNo ={number}";
            SqlCommand command = new SqlCommand(selectQuery, connection);
            command.ExecuteNonQuery();
            connection.Close();

            Console.WriteLine("<========================================>");
            Console.WriteLine("Yenilenmiw istifadeci");
            EmployeeManager.EmployeeReader(number);

        }

        public static void GetDeleteEmployee()
        {
            Console.WriteLine("Silinen iscinin nomresini daxil edin");
            int number = Convert.ToInt32(Console.ReadLine());
            SqlConnection connection = new SqlConnection(stringdatasource);
            connection.Open();
            string selectQuery = $"delete from Employee  where [EmployeeNo]={number}";
            SqlCommand command = new SqlCommand(selectQuery, connection);

            try
            {
                command.ExecuteReader();
                Console.WriteLine("Emelyat ugurludur");
            }
            catch (Exception)
            {

                Console.WriteLine("Emelyat ugursuzdur. Daxil etdiyiniz nomreli iwci bazada yoxdur");
            }


            connection.Close();


        }

        public static void GetAddEmployee()
        {
            Console.WriteLine("isdifadecinin nomresini  daxil edin");
            int number= Convert.ToInt32(Console.ReadLine());
            SqlConnection connection = new SqlConnection(stringdatasource);
            connection.Open();
         
                string selectQuery = $"SELECT [EmployeeNO], [Name], [SurName], [EntryTime], [Adress], [WagePer], [TotalMinPerMonth] FROM [dbo].[Employee] where EmployeeNO ={number}";
                SqlCommand sqlCommand = new SqlCommand(selectQuery, connection);
                SqlDataReader sqlDataReader;
                sqlDataReader = sqlCommand.ExecuteReader();


                if(sqlDataReader.HasRows != false)
                {
                    while (sqlDataReader.Read())
                    {
                        Console.WriteLine($"Istifadeci nomresi {(int)sqlDataReader.GetValue(0)}");
                        Console.WriteLine($"Istifadeci adi {(string)sqlDataReader.GetValue(1)}");
                        Console.WriteLine($"Istifadeci soyadi {(string)sqlDataReader.GetValue(2)}");
                        Console.WriteLine($"Istifadeci giriw vaxti {(DateTime)sqlDataReader.GetValue(3)}");
                        Console.WriteLine($"Istifadeci adresi {(string)sqlDataReader.GetValue(4)}");
                        Console.WriteLine($"Istifadeci iw emsai {(int)sqlDataReader.GetValue(5)}");
                        Console.WriteLine($"Istifadeci 1 ay erzinden iwlediyi deqiqe {(int)sqlDataReader.GetValue(6)}");
                    }
                    Console.WriteLine("<========================================>");
                }
                else
                {
                sqlDataReader.Close();
                Console.WriteLine("Bele bir istifadeci yoxdur. Yeni istifadeci yaradilir");

                Console.WriteLine("Yeni adi daxil edin");
                string name = Console.ReadLine();
                Console.WriteLine("Yeni soyadi daxil edin");
                string surname = Console.ReadLine();

                Console.WriteLine("Yeni iw vaxtini daxil edin (gun.ay.il)");
                DateTime entryTime = Convert.ToDateTime(Convert.ToDateTime(Console.ReadLine()).ToString("dd/MM/yyyy"));


                Console.WriteLine("Yeni adresi daxil edin");
                string adress = Console.ReadLine();

                Console.WriteLine("Yeni iw emsalini daxil edin");
                int wagePer = Convert.ToInt32(Console.ReadLine());
                string insertQuery = $"INSERT INTO [dbo].[Employee]( [EmployeeNO], [Name], [SurName], [EntryTime], [Adress], [WagePer], [TotalMinPerMonth]) VALUES({number}, '{name}', '{surname}', '{entryTime}', '{adress}', {wagePer}, {0})";
                SqlCommand command = new SqlCommand(insertQuery, connection);
                command.ExecuteNonQuery();

                Console.WriteLine("<========================================>");

                try
                {
                    command.ExecuteReader();
                    Console.WriteLine("Emelyat ugurludur");

                    EmployeeManager.EmployeeReader(number);

                }
                catch (Exception)
                {
                    Console.WriteLine("Emeliyyat ugursuzdur.Isci bazada movcuddur!");
                }

              
                connection.Close();
            }

        

          

          



        }
    }
}
