﻿using IKMIVIP.Enum;
using Intuit.Ipp.Data;
using System;
using System.Collections.Generic;

namespace IKMIVIP
{
    internal class Program
    {



        static void Main(string[] args)
        {
        optionInput:
            Console.WriteLine("1.Sorgulama programi");
            Console.WriteLine("2.Yenileme programi");
            string option = Console.ReadLine();

            if (option == "1")
            {
                optionsInput:
                Console.WriteLine("1.Iscinin melumatlarinin gosterilmesi");
                Console.WriteLine("2.Ay uzre melumatlarin gosterilmesi");
                Console.WriteLine("3.Müəyyən bir ünvana görə işçilərin siyahısının görüntülənməsi.");
                Console.WriteLine("4.İşə qəbul olunan işçilərin sayının illər üzrə bölgüsünün görüntülənməsi.");
                Console.WriteLine("5. İşə gec gələn işçilərin siyahısı");
               

                string options = Console.ReadLine();
                if (options == "1")
                {
                    Console.WriteLine("Isdifadecinin Nomresini daxil edin");
                    int number = Convert.ToInt32(Console.ReadLine());
                    EmployeeManager.EmployeeReader(number);

                }
                else if(options == "3")
                {
                    EmployeeManager.EmployeeGetAdress();
                }
                else if(options == "2")
                {
                   EmployeeManager.EmployeeGetInfoPerMonth();
                }
                else if (options =="4")
                {
                    EmployeeManager.EmployyeCountPerYear();
                }
                else if (options =="5")
                {
                    EmployeeManager.EmployeeGotLater();
                }
                else
                {
                    goto optionsInput;
                }



            }
            else if (option == "2")
            {
                Console.WriteLine("1.Yeni işçinin əlavə edilməsi");
                Console.WriteLine("2.İşçi məlumatlarının yenilənməsi");
                Console.WriteLine("3.Müəyyən bir günün iş qeydlərinin əlavə edilməsi");
                Console.WriteLine("4.İşçi məlumatlarının dosyalardan silinməsi");
                Console.WriteLine("5.İşçilər faylının ehtiyat nüsxəsinin çıxarılması");


                string opt = Console.ReadLine();

                if (opt=="2")
                {
                    EmployeeManager.EmployeeUpdate();
                }
                else if (opt=="4")
                {
                    EmployeeManager.GetDeleteEmployee();
                }
                else if (opt=="1")
                {
                    EmployeeManager.GetAddEmployee();
                }
            }
            else
            {
                goto optionInput;
            }



        }
    }
}
