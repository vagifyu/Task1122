﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IKMIVIP
{
    public class Employee
    {
        public int ID
        {
            get
            {
                return ID;
            }
            set
            {
                do
                {
                    ID = value;
                } while (ID > 0 && ID < 101);
            }
        }
        public string Name
        {
            get
            {
                return Name;
            }
            set
            {
                char[] chars = Name.ToCharArray();
                if (chars.Length < 25)
                {
                    Name = value;
                }
                else
                    throw new ArgumentException();
            }
        }
        public string SurName
        {
            get
            {
                return SurName;
            }
            set
            {

                char[] chars = SurName.ToCharArray();
                if (chars.Length < 25)
                {
                    SurName = value;
                }
                else
                    throw new ArgumentException();
            }
        }
        public DateTime EntryTime
        {
            get
            {
                DateTime dt = DateTime.Now;
                return dt;
            }
            set
            {
                string txt1 = "yyyy - mm - dd";
                DateTime dt = DateTime.ParseExact(txt1, "yyyy-mm-dd", null);
                txt1 = value.ToString();
            }
        }
        public string Adress
        {
            get
            {
                return Adress;
            }
            set
            {
                char[] chars = Adress.ToCharArray();
                if (chars.Length < 15)
                {
                    Adress = value;
                }
                else
                    throw new ArgumentException();
            }
        }
        public double WagePer { get; set; }
        public long TotalMinPerMonth
        {
            get
            {
                return TotalMinPerMonth;
            }
            set
            {

            }
        }

        public static void TotalMinsPerMonth()
        {
            DateTime date1 = new DateTime(2022, 7, 01, 08, 15, 20);
            DateTime date2 = new DateTime(2022, 8, 01, 17, 15, 20);
            TimeSpan ts = date1 - date2;
            Console.WriteLine("No. of Minutes (Difference) = {0}", ts.
                TotalMinutes);
        }

        List<Employee> Employees = new List<Employee>();
       
    }   }
