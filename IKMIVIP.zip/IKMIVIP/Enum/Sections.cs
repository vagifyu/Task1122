﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IKMIVIP.Enum
{
    internal enum Sections
    {
        SorgulamaProgrami,
        YenilemeProgrami
    }
}
